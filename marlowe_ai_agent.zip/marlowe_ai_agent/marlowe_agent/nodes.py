from __future__ import annotations

from typing import Any
from collections.abc import Callable

from .logic_graph import LogicGraphVerifier
from .models import ContractDraft, LogicGraphResult, PipelineResult, TraceEvent, VerificationResult


class PromptToDraftNode:
    def __init__(self, reasoner: Any) -> None:
        self.reasoner = reasoner

    def run(self, prompt: str) -> ContractDraft:
        return self.reasoner.draft_from_prompt(prompt)


class SemanticVerificationNode:
    def __init__(self, reasoner: Any) -> None:
        self.reasoner = reasoner

    def run(self, prompt: str, draft: ContractDraft) -> VerificationResult:
        return self.reasoner.semantic_verify(prompt, draft)


class ClarificationNode:
    def __init__(self, interactive: bool) -> None:
        self.interactive = interactive

    def run(self, prompt: str, verification: VerificationResult) -> str:
        if verification.passed or not self.interactive:
            return prompt

        additions: list[str] = []
        questions = verification.questions
        if not questions:
            return prompt
        for index, question in enumerate(questions, start=1):
            answer = input(f"Cau hoi {index}: {question}\n> ").strip()
            if answer:
                additions.append(f"- {question}\n  Tra loi: {answer}")
        if not additions:
            return prompt
        return prompt + "\n\nThong tin bo sung tu nguoi dung:\n" + "\n".join(additions)


class LogicGraphVerificationNode:
    def __init__(self) -> None:
        self.verifier = LogicGraphVerifier()

    def run(self, draft: ContractDraft) -> LogicGraphResult:
        return self.verifier.verify(draft.marlowe_contract)


TraceCallback = Callable[[TraceEvent], None]


class AgentPipeline:
    def __init__(
        self,
        reasoner: Any,
        interactive: bool = False,
        max_iterations: int = 4,
        require_semantic_pass: bool = True,
        trace_callback: TraceCallback | None = None,
    ) -> None:
        self.node_1 = PromptToDraftNode(reasoner)
        self.node_2 = SemanticVerificationNode(reasoner)
        self.node_3 = ClarificationNode(interactive)
        self.node_4 = LogicGraphVerificationNode()
        self.max_iterations = max_iterations
        self.require_semantic_pass = require_semantic_pass
        self.trace_callback = trace_callback
        self.trace: list[TraceEvent] = []

    def track(self, node: str, status: str, message: str, data: dict | None = None) -> None:
        event = TraceEvent(node=node, status=status, message=message, data=data or {})
        self.trace.append(event)
        if self.trace_callback:
            self.trace_callback(event)

    def run(self, prompt: str) -> PipelineResult:
        current_prompt = prompt
        self.track(
            "pipeline",
            "start",
            "Đã nhận prompt của người dùng và bắt đầu chu trình agent.",
            {"prompt_preview": prompt[:240], "max_iterations": self.max_iterations},
        )

        self.track("node_1_prompt_to_draft", "start", "Model đang đọc hiểu prompt và sinh bản phác thảo Marlowe.")
        draft = self.node_1.run(current_prompt)
        self.track(
            "node_1_prompt_to_draft",
            "done",
            "Model đã sinh bản phác thảo.",
            {
                "intent": draft.intent,
                "parties": [party.to_dict() for party in draft.parties],
                "amount": draft.amount,
                "clauses_count": len(draft.clauses),
                "assumptions_count": len(draft.assumptions),
                "reasoning_summary": draft.reasoning_summary,
                "reasoning_narrative": draft.reasoning_narrative,
                "contract_root": next(iter(draft.marlowe_contract.keys()), None) if draft.marlowe_contract else None,
            },
        )

        self.track("node_2_semantic_verification", "start", "Model đang kiểm chứng semantic giữa prompt và draft.")
        semantic = self.node_2.run(current_prompt, draft)
        self.track(
            "node_2_semantic_verification",
            "pass" if semantic.passed else "fail",
            "Model đã hoàn tất kiểm chứng semantic.",
            {
                "score": semantic.score,
                "reasoning_summary": semantic.reasoning_summary,
                "reasoning_narrative": semantic.reasoning_narrative,
                "findings": semantic.findings,
                "questions": semantic.questions,
            },
        )

        iterations = 1
        while not semantic.passed and iterations < self.max_iterations:
            self.track(
                "node_3_clarification",
                "start",
                "Semantic chưa đạt; chuyển sang vòng hỏi bổ sung.",
                {"iteration": iterations, "questions": semantic.questions},
            )
            next_prompt = self.node_3.run(current_prompt, semantic)
            if next_prompt == current_prompt:
                self.track(
                    "node_3_clarification",
                    "blocked",
                    "Không có thông tin bổ sung; workflow không thể tiếp tục an toàn.",
                )
                break
            current_prompt = next_prompt
            self.track(
                "node_3_clarification",
                "done",
                "Đã ghép thông tin bổ sung vào prompt; yêu cầu model sinh lại draft.",
                {"iteration": iterations + 1},
            )

            self.track("node_1_prompt_to_draft", "start", "Model đang sinh lại draft từ prompt đã bổ sung.")
            draft = self.node_1.run(current_prompt)
            self.track(
                "node_1_prompt_to_draft",
                "done",
                "Model đã sinh lại draft.",
                {
                    "intent": draft.intent,
                    "parties": [party.to_dict() for party in draft.parties],
                    "amount": draft.amount,
                    "clauses_count": len(draft.clauses),
                    "assumptions_count": len(draft.assumptions),
                    "reasoning_summary": draft.reasoning_summary,
                    "reasoning_narrative": draft.reasoning_narrative,
                    "contract_root": next(iter(draft.marlowe_contract.keys()), None) if draft.marlowe_contract else None,
                },
            )

            self.track("node_2_semantic_verification", "start", "Model đang kiểm chứng lại draft sau bổ sung.")
            semantic = self.node_2.run(current_prompt, draft)
            self.track(
                "node_2_semantic_verification",
            "pass" if semantic.passed else "fail",
            "Model đã hoàn tất kiểm chứng semantic sau bổ sung.",
            {
                "score": semantic.score,
                "reasoning_summary": semantic.reasoning_summary,
                "reasoning_narrative": semantic.reasoning_narrative,
                "findings": semantic.findings,
                "questions": semantic.questions,
            },
            )
            iterations += 1

        if self.require_semantic_pass and not semantic.passed:
            logic = LogicGraphResult(
                passed=False,
                findings=[
                    "Skipped logic graph verification because semantic verification did not pass.",
                    "Có thể tiếp tục bổ sung thông tin theo questions trước khi sinh hợp đồng Marlowe đáng tin.",
                ],
                graph={"nodes": [], "edges": []},
            )
            self.track(
                "node_4_logic_graph_verification",
                "skipped",
                "Cổng semantic chưa đạt; không chạy kiểm chứng logic graph.",
                {"semantic_findings": semantic.findings, "semantic_questions": semantic.questions},
            )
            self.track(
                "pipeline",
                "blocked",
                "Workflow dừng trước bước kiểm chứng hợp đồng cuối.",
                {"iterations": iterations, "semantic_passed": semantic.passed, "logic_passed": logic.passed},
            )
            return PipelineResult(
                draft=draft,
                semantic_verification=semantic,
                logic_verification=logic,
                iterations=iterations,
                trace=self.trace,
            )

        self.track("node_4_logic_graph_verification", "start", "Đang dựng graph nhánh và kiểm chứng logic hợp đồng.")
        logic = self.node_4.run(draft)
        self.track(
            "node_4_logic_graph_verification",
            "pass" if logic.passed else "fail",
            "Đã hoàn tất kiểm chứng logic graph.",
            {
                "findings": logic.findings,
                "nodes_count": len(logic.graph.get("nodes", [])),
                "edges_count": len(logic.graph.get("edges", [])),
            },
        )
        self.track(
            "pipeline",
            "done",
            "Workflow agent đã hoàn tất.",
            {"iterations": iterations, "semantic_passed": semantic.passed, "logic_passed": logic.passed},
        )
        return PipelineResult(
            draft=draft,
            semantic_verification=semantic,
            logic_verification=logic,
            iterations=iterations,
            trace=self.trace,
        )
