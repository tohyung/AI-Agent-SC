from marlowe_agent.cli import main


if __name__ == "__main__":
    main()
